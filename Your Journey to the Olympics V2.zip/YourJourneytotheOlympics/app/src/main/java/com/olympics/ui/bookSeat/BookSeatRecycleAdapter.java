package com.olympics.ui.bookSeat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Bus;
import com.olympics.R;

import java.util.ArrayList;

public class BookSeatRecycleAdapter extends RecyclerView.Adapter<BookSeatRecycleAdapter.Holder> {
    Context mContext;
    ItemClickListener mListener;
    Bus mData;
    int bookCount = 0;
    ArrayList<ImageView> imgBook = new ArrayList<>();
    public BookSeatRecycleAdapter(Context mContext, Bus mData){
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(mContext).inflate(R.layout.item_bus_seat,parent,false);
        final boolean[] check = {true,true,true,true};
        final Holder holder = new Holder(view);
        holder.seat1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check[0] && bookCount< 2) {
                    holder.seat1.setImageResource(R.drawable.seat_booking);
                    bookCount++;
                    imgBook.add(holder.seat1);
                    check[0] = false;
                }
                else if (!check[0]){
                    holder.seat1.setImageResource(R.drawable.seat_notbook);
                    bookCount--;
                    imgBook.remove(holder.seat1);
                    check[0] = true;
                }
                else {Toast.makeText(mContext,"Cannot Book!!",Toast.LENGTH_SHORT).show();}
            }

        });
        holder.seat2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check[1] && bookCount< 2) {
                    holder.seat2.setImageResource(R.drawable.seat_booking);
                    bookCount++;
                    imgBook.add(holder.seat2);
                    check[1] = false;
                }
                else if (!check[1]){
                    holder.seat2.setImageResource(R.drawable.seat_notbook);
                    bookCount--;
                    imgBook.remove(holder.seat2);
                    check[1] = true;
                }
                else {Toast.makeText(mContext,"Cannot Book!!",Toast.LENGTH_SHORT).show();}


            }
        });
        holder.seat3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if (check[2] && bookCount < 2) {
                        holder.seat3.setImageResource(R.drawable.seat_booking);
                        bookCount++;
                        imgBook.add(holder.seat3);
                        check[2] = false;
                    }
                    else if (!check[2]){
                        holder.seat3.setImageResource(R.drawable.seat_notbook);
                        bookCount--;
                        imgBook.remove(holder.seat3);
                        check[2] = true;
                    }
                    else {Toast.makeText(mContext,"Cannot Book!!",Toast.LENGTH_SHORT).show();}

            }
        });
        holder.seat4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if (check[3] && bookCount<2) {
                    holder.seat4.setImageResource(R.drawable.seat_booking);
                    bookCount++;
                        imgBook.add(holder.seat4);
                    check[3] = false;
                }
                else if (!check[3]){
                    holder.seat4.setImageResource(R.drawable.seat_notbook);
                    bookCount--;
                    imgBook.remove(holder.seat4);
                    check[3] = true;
                }
                else {Toast.makeText(mContext,"Cannot Book!!",Toast.LENGTH_SHORT).show();}

            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        if(mData.getBusType().equals("Type A")){
            holder.seat1.setImageResource(R.drawable.seat_notbook);
            holder.seat1.setClickable(true);
            holder.seat2.setImageResource(R.drawable.seat_notbook);
            holder.seat2.setClickable(true);
            holder.seat3.setImageResource(R.drawable.seat_notbook);
            holder.seat3.setClickable(true);
            holder.seat4.setImageResource(R.drawable.seat_notbook);
            holder.seat4.setClickable(true);
        }
        else{
            holder.seat1.setClickable(false);
            holder.seat4.setClickable(false);
            holder.seat2.setImageResource(R.drawable.seat_notbook);
            holder.seat2.setClickable(true);
            holder.seat3.setImageResource(R.drawable.seat_notbook);
            holder.seat3.setClickable(true);
        }
    }

    @Override
    public int getItemCount() {
        return mData.getRows();
    }
    public void setItemClickListener(ItemClickListener listener){
        this.mListener = listener;
    }
    public void bookSeat(){
        if(bookCount == 0){
            Toast.makeText(mContext,"Plese select!!",Toast.LENGTH_SHORT).show();
        }
        else{
            for (ImageView i:imgBook) {
                i.setImageResource(R.drawable.seat_booked);
                i.setClickable(false);
                
            }
        }
    }
    class Holder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private ImageView seat1;
        private ImageView seat2;
        private ImageView seat3;
        private ImageView seat4;

        public Holder(@NonNull View itemView) {
            super(itemView);
            seat1 = (ImageView)itemView.findViewById(R.id.seat1);
            seat2 = (ImageView)itemView.findViewById(R.id.seat2);
            seat3 = (ImageView)itemView.findViewById(R.id.seat3);
            seat4 = (ImageView)itemView.findViewById(R.id.seat4);

        }
        @Override
        public void onClick(View v) {
            if(mListener != null);
                mListener.onItemClick(getLayoutPosition());
        }

    }
    public interface ItemClickListener{
        void onItemClick(int position);
    }
}
