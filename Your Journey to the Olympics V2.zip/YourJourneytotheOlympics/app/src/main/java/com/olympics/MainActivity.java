package com.olympics;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.olympics.ui.booking.BookingFragment;
import com.olympics.ui.home.EventFragment;
import com.olympics.ui.profile.ProfileFragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String allLine = "";
    private static ArrayList<Event> eventList = new ArrayList<>();;
    private static ArrayList<Bus> busList = new ArrayList<>();
    private static ArrayList<Account> accountList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GlobalClass globalClass = (GlobalClass) getApplicationContext();
        readFile();
        listCreated();
        globalClass.setEvents(eventList);
        globalClass.setBuses(busList);
        globalClass.setAccounts(accountList);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(navListener);
        EventFragment eventFragment = new EventFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,eventFragment).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;
                    switch (item.getItemId()){
                        case R.id.navigation_home:
                            EventFragment eventFragment = new EventFragment();
                            //eventFragment.sendToEventFragment(eventList);
                            selectedFragment = eventFragment;
                            break;
                        case R.id.navigation_booking:
                            selectedFragment = new BookingFragment();
                            break;
                        case R.id.navigation_profile:
                            selectedFragment = new ProfileFragment();
                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,selectedFragment).commit();

                    return true;
                }
            };
    public void readFile(){
        try {
            InputStream is = getResources().openRawResource(R.raw.input);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while (reader.ready()) {
                line = reader.readLine() + "\n";
                if (line.contains("//")){continue;}
                if (line.contains("Event")){
                    line = line.replace("Event","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",9);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addEvents(lineArr);
                }
                else if (line.contains("Bus")){
                    line = line.replace("Bus","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",8);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addBuses(lineArr);
                }
                else if (line.contains("Account")){
                    line = line.replace("Account","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",3);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addAccounts(lineArr);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String getAllLine(){
        readFile();
        return allLine;
    }
    public void listCreated(){
        for (int i = 0; i < new FileManager().getEvents().size() ; i++) {
            eventList.add(new Event(i));
        }

        for (int i = 0; i < new FileManager().getBuses().size() ; i++) {
            busList.add(new Bus(i));
        }
        for (int i = 0; i < new FileManager().getAccounts().size() ; i++) {
            accountList.add(new Account(i));
        }
    }
}


