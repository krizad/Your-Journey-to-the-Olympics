package com.olympics;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;

public class Account extends FileManager {
    private String accNo;
    private String userID;
    private String password;
    private ArrayList<String[]> card = new ArrayList<>();
    private int cardCnt = 0;
    public Account(int index) {
        this.accNo = super.getAccounts().get(index)[0];
        this.userID = super.getAccounts().get(index)[1];
        this.password = super.getAccounts().get(index)[2];
    }
    public Account(String userID,String password){
        this.accNo = getAccounts().size()+1+"";
        this.userID = userID;
        this.password = password;
    }
    public Account(String userID,String password,String card,String csvCode){
        this.accNo = getAccounts().size()+1+"";
        this.userID = userID;
        this.password = password;
        addCard(card,csvCode);
    }
    public void addCard(String card,String csvCode){
        cardCnt++;
        String cnt = ""+cardCnt;
        String[] c = {cnt,card,csvCode};
        this.card.add(c);
    }
    public void removeCard(String[] card){
        this.card.remove(card);
    }
    public void setPassword(String newPassword){
        this.password = newPassword;
    }

    public String getAccNo() {
        return accNo;
    }

    public String getUserID() {
        return userID;
    }

    public String getPassword() {
        return password;
    }

    public ArrayList<String[]> getCard() {
        return card;
    }
    @Override
    public String toString(){
        String cardDetail="";
        if (cardCnt>0){
        for (String[] c: getCard()) {
            cardDetail += "Card "+c[0]+" : "+c[1]+" CSV : "+c[2]+"\n";
        }}
        return "UserID : "+getUserID()+"\n"+"Password : "+getPassword()+"\n"+cardDetail;
    }
}
