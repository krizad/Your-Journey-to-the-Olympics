package com.olympics.ui.home;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.olympics.Event;
import com.olympics.R;
import com.olympics.ui.busToEvent.BusToEventFragment;

import java.util.ArrayList;
import java.util.List;

import static com.olympics.R.id.book_button;

public class EventFragment extends Fragment {
    private RecyclerView eventRecycleView;
    private List<Event> listEvent;
    Dialog eventDialog;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        eventRecycleView = (RecyclerView)root.findViewById(R.id.home_recycle);
        final EventRecycleAdapter recycleAdapter = new EventRecycleAdapter(getContext(),listEvent);
        eventRecycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
        eventRecycleView.setAdapter(recycleAdapter);
        recycleAdapter.setItemClickListener(new EventRecycleAdapter.ItemClickListener() {
            @Override
            public void onItemClick(final int position) {
                Toast.makeText(getContext(), "asdasdasd"+position, Toast.LENGTH_SHORT).show();
                //setDialog
                TextView dia_sport = (TextView) eventDialog.findViewById(R.id.dia_sport);
                TextView dialog_discipline = (TextView) eventDialog.findViewById(R.id.dia_discipline);
                TextView dia_category = (TextView) eventDialog.findViewById(R.id.dia_category);
                TextView dia_venue = (TextView) eventDialog.findViewById(R.id.dia_venue);
                TextView dia_date = (TextView) eventDialog.findViewById(R.id.dia_date);
                TextView dia_startTime = (TextView) eventDialog.findViewById(R.id.dia_startTime);
                TextView dia_duration = (TextView) eventDialog.findViewById(R.id.dia_duration);
                TextView dia_busTravelTime = (TextView) eventDialog.findViewById(R.id.dia_busTravelTime);
                final Button book = (Button)eventDialog.findViewById(book_button);
                dia_sport.setText(recycleAdapter.mData.get(position).getSport());
                dialog_discipline.setText(recycleAdapter.mData.get(position).getDiscipline());
                dia_category.setText(recycleAdapter.mData.get(position).getCategory());
                dia_venue.setText("Venue : " + recycleAdapter.mData.get(position).getVenue());
                dia_date.setText("Date : " + recycleAdapter.mData.get(position).getDate());
                dia_startTime.setText("Start Time : " + recycleAdapter.mData.get(position).getStartTime());
                dia_duration.setText("Duration : " + recycleAdapter.mData.get(position).getDuration());
                dia_busTravelTime.setText("Travel By Bus : " + recycleAdapter.mData.get(position).getBusTravelTime());
                eventDialog.show();
                book.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BusToEventFragment busToEventFragment = new BusToEventFragment();
                        Bundle bundle = new Bundle();
                        bundle.putInt("index",recycleAdapter.mData.get(position).getEventIndex());
                        busToEventFragment.setArguments(bundle);
                        getActivity().getSupportFragmentManager().beginTransaction()
                                .replace(R.id.nav_host_fragment, busToEventFragment).commit();
                        eventDialog.cancel();
                    }
                });


            }
        });
    return root;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Event event1 = new Event(0);
        Event event2 = new Event(1);
        Event event3 = new Event(2);
        Event event4 = new Event(3);
        Event event5 = new Event(4);
        Event event6 = new Event(5);
        Event event7 = new Event(6);
        Event event8 = new Event(7);
        Event event9 = new Event(8);
        Event event10 = new Event(9);
        Event event11 = new Event(10);
        listEvent = new ArrayList<>();
        listEvent.add(event1);
        listEvent.add(event2);
        listEvent.add(event3);
        listEvent.add(event4);
        listEvent.add(event5);
        listEvent.add(event6);
        listEvent.add(event7);
        listEvent.add(event8);
        listEvent.add(event9);
        listEvent.add(event10);
        listEvent.add(event11);
        listEvent.add(event11);
        eventDialog = new Dialog(getContext());
        eventDialog.setContentView(R.layout.dialog_event);
    }
}
