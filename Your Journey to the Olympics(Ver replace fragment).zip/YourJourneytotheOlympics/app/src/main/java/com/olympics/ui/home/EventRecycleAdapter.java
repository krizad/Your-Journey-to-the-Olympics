package com.olympics.ui.home;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Event;
import com.olympics.R;

import java.util.List;

public class EventRecycleAdapter extends RecyclerView.Adapter<EventRecycleAdapter.MyViewHolder> {
    Context mContext;
    List<Event> mData;
    ItemClickListener mListener;
    Dialog eventDialog;
    public EventRecycleAdapter(Context mContext, List<Event> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(mContext).inflate(R.layout.item_event, parent, false);
        final MyViewHolder vHolder = new MyViewHolder(v);
        //Dialog init
        /*eventDialog = new Dialog(mContext);
        eventDialog.setContentView(R.layout.dialog_event);
        vHolder.item_Event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView dia_sport = (TextView) eventDialog.findViewById(R.id.dia_sport);
                TextView dialog_discipline = (TextView) eventDialog.findViewById(R.id.dia_discipline);
                TextView dia_category = (TextView) eventDialog.findViewById(R.id.dia_category);
                TextView dia_venue = (TextView) eventDialog.findViewById(R.id.dia_venue);
                TextView dia_date = (TextView) eventDialog.findViewById(R.id.dia_date);
                TextView dia_startTime = (TextView) eventDialog.findViewById(R.id.dia_startTime);
                TextView dia_duration = (TextView) eventDialog.findViewById(R.id.dia_duration);
                TextView dia_busTravelTime = (TextView) eventDialog.findViewById(R.id.dia_busTravelTime);
                dia_sport.setText(mData.get(vHolder.getAdapterPosition()).getSport());
                dialog_discipline.setText(mData.get(vHolder.getAdapterPosition()).getDiscipline());
                dia_category.setText(mData.get(vHolder.getAdapterPosition()).getCategory());
                dia_venue.setText("Venue : " + mData.get(vHolder.getAdapterPosition()).getVenue());
                dia_date.setText("Date : " + mData.get(vHolder.getAdapterPosition()).getDate());
                dia_startTime.setText("Start Time : " + mData.get(vHolder.getAdapterPosition()).getStartTime());
                dia_duration.setText("Duration : " + mData.get(vHolder.getAdapterPosition()).getDuration());
                dia_busTravelTime.setText("Travel By Bus : " + mData.get(vHolder.getAdapterPosition()).getBusTravelTime());
                eventDialog.show();
                final Button book = eventDialog.findViewById(R.id.book_button);
                book.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Toast.makeText(mContext, "asd", Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(mContext, EventDetail.class);
                        i.putExtra("EventId", mData.get(vHolder.getAdapterPosition()).getEventID());
                        //eventDialog.cancel();
                        mContext.startActivity(i);


                    }
                });

            }
        });*/
        return vHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tv_sport.setText(mData.get(position).getSport());
        holder.tv_discipline.setText(mData.get(position).getDiscipline());
        holder.tv_category.setText(mData.get(position).getCategory());
        holder.img.setImageResource(mData.get(position).getPhoto());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
    public void setItemClickListener(ItemClickListener listener){
        this.mListener = listener;
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView tv_sport;
        private TextView tv_discipline;
        private TextView tv_category;
        private ImageView img;
        private LinearLayout item_Event;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_sport = (TextView) itemView.findViewById(R.id.event_sport);
            tv_discipline = (TextView) itemView.findViewById(R.id.event_discipline);
            tv_category = (TextView) itemView.findViewById(R.id.event_category);
            img = (ImageView) itemView.findViewById(R.id.event_img);
            item_Event = (LinearLayout) itemView.findViewById(R.id.event_item);
            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View view){
            if(mListener!=null)
                mListener.onItemClick(getAdapterPosition());
        }
    }
    public interface ItemClickListener{
        void onItemClick(int position);
    }
}

