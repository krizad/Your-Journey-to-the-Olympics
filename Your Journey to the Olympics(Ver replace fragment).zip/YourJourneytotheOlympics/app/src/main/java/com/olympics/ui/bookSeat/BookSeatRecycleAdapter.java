package com.olympics.ui.bookSeat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Bus;
import com.olympics.R;

public class BookSeatRecycleAdapter extends RecyclerView.Adapter<BookSeatRecycleAdapter.Holder> {
    Context mContext;
    ItemClickListener mListener;
    Bus mData;
    public BookSeatRecycleAdapter(Context mContext, Bus mData){
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_bus_seat,parent,false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        if(mData.getBusType().equals("Type A")){
            holder.seat1.setImageResource(R.drawable.seat_notbook);
            holder.seat1.setClickable(true);
            holder.seat2.setImageResource(R.drawable.seat_notbook);
            holder.seat2.setClickable(true);
            holder.seat3.setImageResource(R.drawable.seat_notbook);
            holder.seat3.setClickable(true);
            holder.seat4.setImageResource(R.drawable.seat_notbook);
            holder.seat4.setClickable(true);
        }
        else{
            holder.seat2.setImageResource(R.drawable.seat_notbook);
            holder.seat2.setClickable(true);
            holder.seat3.setImageResource(R.drawable.seat_notbook);
            holder.seat3.setClickable(true);
        }
    }

    @Override
    public int getItemCount() {
        return mData.getRows();
    }
    public void setItemClickListener(ItemClickListener listener){
        this.mListener = listener;
    }

    class Holder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private ImageView seat1;
        private ImageView seat2;
        private ImageView seat3;
        private ImageView seat4;
        public Holder(@NonNull View itemView) {
            super(itemView);
            seat1 = (ImageView)itemView.findViewById(R.id.seat1);
            seat2 = (ImageView)itemView.findViewById(R.id.seat2);
            seat3 = (ImageView)itemView.findViewById(R.id.seat3);
            seat4 = (ImageView)itemView.findViewById(R.id.seat4);
        }
        @Override
        public void onClick(View v) {
            if(mListener != null);
                mListener.onItemClick(getAdapterPosition());
        }

    }
    public interface ItemClickListener{
        void onItemClick(int position);
    }
}
