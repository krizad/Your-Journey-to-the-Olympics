package com.olympics;

import java.sql.Time;
import java.util.ArrayList;

public class Event extends FileManager{
    private String EventID;
    private String sport;
    private String discipline;
    private String category;
    private String venue;
    private String date;
    private String startTime;
    private String duration;
    private String busTravelTime;
    private int photo;


    public Event(){}
    public Event(int index){
        super();
        this.EventID = super.getEvents().get(index)[0];
        this.sport = super.getEvents().get(index)[1];
        this.discipline = super.getEvents().get(index)[2];
        this.category = super.getEvents().get(index)[3];
        this.venue = super.getEvents().get(index)[4];
        this.date = super.getEvents().get(index)[5];
        this.startTime = super.getEvents().get(index)[6];
        this.duration = super.getEvents().get(index)[7];
        this.busTravelTime = super.getEvents().get(index)[8];
        if (sport.equals("Ceremony")){this.photo = R.drawable.ceremony;}
        else if (sport.equals("Athletics")){this.photo = R.drawable.ic_date_range_black_24dp;}
        else if (sport.equals("Swimming")){this.photo = R.drawable.swimming;}
        else if (sport.equals("Diving")){this.photo = R.drawable.ic_launcher_background;}
        else if (sport.equals("Weightlifting")){this.photo = R.drawable.ic_launcher_foreground;}
        else {this.photo = R.mipmap.app_icon;}
    }

    public int getEventID() {
        return Integer.parseInt(EventID);
    }
    public int getEventIndex(){return getEventID()-1;}
    public String getSport() {
        return sport;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getCategory() {
        return category;
    }

    public String getVenue() {
        return venue;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }
    public String getDuration() {
        /*int time;
        if (duration.contains(".")){
        int hour = Integer.parseInt(duration.substring(0,duration.indexOf(".")));
        int min = Integer.parseInt(duration.substring(duration.indexOf(".")+1,duration.length()));
        time = hour*60 + min;}
        else {time = Integer.parseInt(duration)*60;}*/

        return duration;
    }
    public String getBusTravelTime() {
        //int busTravelTime = Integer.parseInt(this.busTravelTime);
        return busTravelTime;
    }
    public int getPhoto() {
        return photo;
    }
    public ArrayList<Bus> getBusToEvent(){
        ArrayList<Bus> busToEvent = new ArrayList<>();
        for (String[] a: super.getBuses()) {
            String depart = a[3];
            int depart_hour = Integer.parseInt(depart.substring(0,depart.indexOf("."))) ;
            int depart_min = Integer.parseInt(depart.substring(depart.indexOf(".")+1)) ;
            depart_min+= Integer.parseInt(getBusTravelTime());
            if(depart_min>=60){
                depart_hour++;
                depart_min-=60;
            }
            int arrive_hour = depart_hour;
            int arrive_min = depart_min;
            int start_hour = Integer.parseInt(getStartTime().substring(0,getStartTime().indexOf(".")));
            int start_min = Integer.parseInt(getStartTime().substring(getStartTime().indexOf(".")+1));

            //before Start 2 hour
            int before_hour = start_hour-2;
            int before_min;
            Boolean beforeCheck = false;
            if(arrive_hour>=before_hour){
                beforeCheck = true;
            }
            //after 1 hour
            int after_hour = start_hour+1;
            int after_min = start_min;
            Boolean affterCheck = false;
            if (arrive_hour<=after_hour){
                if (arrive_hour==after_hour && arrive_min > after_min){
                    affterCheck = false;
                }
                else{affterCheck = true;}
            }


            if((a[2].equals(this.venue)) && beforeCheck && affterCheck){
                busToEvent.add(new Bus(Integer.parseInt(a[0])-1));
            }
        }
        return busToEvent;
    }
    @Override
    public String toString(){
        return "Event ID : "+getEventID()+"\n"+"Sport : "+getSport()+"\n"+"Discipline : "+getDiscipline()+"\n"+"Category : "+getCategory()+"\n"+"Venue : "+getVenue()+"\n"+"Date : "+getDate()+"\n"+"Start time : "+getStartTime()+"\n"+"Duration : "+getDuration()+"\n"+"Bus travel time : "+getBusTravelTime();
    }
}
