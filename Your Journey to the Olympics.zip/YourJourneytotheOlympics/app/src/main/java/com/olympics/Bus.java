package com.olympics;

public class Bus extends FileManager {
    private String busID;
    private String busType;
    private String destination;
    private String depart;
    private String duration;
    private String rows;
    private String cols;
    private String cost;
    public Bus(int index){
        super();
        this.busID = super.getBuses().get(index)[0];
        this.busType = super.getBuses().get(index)[1];
        this.destination= super.getBuses().get(index)[2];
        this.depart= super.getBuses().get(index)[3];
        this.duration= super.getBuses().get(index)[4];
        this.rows= super.getBuses().get(index)[5];
        this.cols= super.getBuses().get(index)[6];
        this.cost= super.getBuses().get(index)[7];
    }

    public int getBusID() {
        return Integer.parseInt(busID);
    }

    public String getBusType() {
        return busType;
    }

    public String getDestination() {
        return destination;
    }

    public String getDepart() {
        return depart;
    }

    public int getDuration() {
        return Integer.parseInt(duration);
    }

    public int getRows() {
        return Integer.parseInt(rows);
    }

    public int getCols() {
        return Integer.parseInt(cols);
    }

    public int getCost() {
        this.cost = this.cost.substring(this.cost.indexOf("B")+1);
        return Integer.parseInt(cost);
    }
    @Override
    public String toString(){
        return "Bus ID : "+getBusID()+"\n"+"Bus Type : "+getBusType()+"\n"+"Destination : "+getDestination()+"\n"+"Depart : "+getDepart()+"\n"+"Duration : "+getDuration()+"\n"+"Rows : "+getRows()+"\n"+"Col : "+getCols()+"\n"+"Cost : "+getCost()+" B";
    }
}
