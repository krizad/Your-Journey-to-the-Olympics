package com.olympics.ui.bookSeat;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.olympics.Account;
import com.olympics.Bus;
import com.olympics.Event;
import com.olympics.GlobalClass;
import com.olympics.R;

import java.util.ArrayList;

public class BookSeatFragment extends Fragment {
    private RecyclerView seatRecycleView;
    private TextView eventDetailBook;
    private int index;
    private String detail="";
    private String seatPosition = "";
    private Bus bus;
    private Event event;
    private Account accountLoggedIn;
    private ArrayList<ImageView> seatList = new ArrayList<>();
    private int[] seatStatus;
    private int bookCount;
    private Dialog bookDialog;
    private Button cancel;
    private Button confirm;

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_bookseat,container,false);

        eventDetailBook = (TextView)root.findViewById(R.id.event_detail_book);
        eventDetailBook.setText(bus.toString()+"\n"+bus.getSeatLeft()+"");

        final GlobalClass globalClass = (GlobalClass)getContext().getApplicationContext();

        final Button book = (Button)root.findViewById(R.id.bookBtn);
        if (bus.getBusType().equals("Type A")){
            seatList.add((ImageView) root.findViewById(R.id.seat1));
            seatList.add((ImageView) root.findViewById(R.id.seat2));
            seatList.add((ImageView) root.findViewById(R.id.seat3));
            seatList.add((ImageView) root.findViewById(R.id.seat4));
            seatList.add((ImageView) root.findViewById(R.id.seat5));
            seatList.add((ImageView) root.findViewById(R.id.seat6));
            seatList.add((ImageView) root.findViewById(R.id.seat7));
            seatList.add((ImageView) root.findViewById(R.id.seat8));
            seatList.add((ImageView) root.findViewById(R.id.seat9));
            seatList.add((ImageView) root.findViewById(R.id.seat10));
            seatList.add((ImageView) root.findViewById(R.id.seat11));
            seatList.add((ImageView) root.findViewById(R.id.seat12));
            seatList.add((ImageView) root.findViewById(R.id.seat13));
            seatList.add((ImageView) root.findViewById(R.id.seat14));
            seatList.add((ImageView) root.findViewById(R.id.seat15));
            seatList.add((ImageView) root.findViewById(R.id.seat16));
            seatList.add((ImageView) root.findViewById(R.id.seat17));
            seatList.add((ImageView) root.findViewById(R.id.seat18));
            seatList.add((ImageView) root.findViewById(R.id.seat19));
            seatList.add((ImageView) root.findViewById(R.id.seat20));
        }
        else if (bus.getBusType().equals("Type B")){
            seatList.add((ImageView) root.findViewById(R.id.seat2));
            seatList.add((ImageView) root.findViewById(R.id.seat3));
            seatList.add((ImageView) root.findViewById(R.id.seat6));
            seatList.add((ImageView) root.findViewById(R.id.seat7));
            seatList.add((ImageView) root.findViewById(R.id.seat10));
            seatList.add((ImageView) root.findViewById(R.id.seat11));
            seatList.add((ImageView) root.findViewById(R.id.seat14));
            seatList.add((ImageView) root.findViewById(R.id.seat15));
            seatList.add((ImageView) root.findViewById(R.id.seat18));
            seatList.add((ImageView) root.findViewById(R.id.seat19));
        }
        seatStatus = bus.getSeatStatus();
            for (final ImageView seat:seatList) {
                seat.setImageResource(R.drawable.seat_notbook);
                if (seatStatus[seatList.indexOf(seat)] == 2 ){
                    seat.setImageResource(R.drawable.seat_booked);
                    seat.setClickable(false);
                }
                else if (seatStatus[seatList.indexOf(seat)] != 2 ){
                    seat.setClickable(true);
                    seat.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!globalClass.isLogIn()){
                                Toast.makeText(getContext().getApplicationContext(),"Please Login",Toast.LENGTH_SHORT).show();
                            }
                            else {
                                if (!accountLoggedIn.canBook(event,bus)){
                                    Toast.makeText(getContext().getApplicationContext(),"Cannot book more than 2 seat in 1 bus",Toast.LENGTH_SHORT).show();
                                }
                                else if (seatStatus[seatList.indexOf(seat)] == 0 && bookCount<2){
                                    seat.setImageResource(R.drawable.seat_booking);
                                    bus.setSeatStatus(seatList.indexOf(seat),1);
                                    bookCount++;
                                }
                                else if (seatStatus[seatList.indexOf(seat)] == 1){
                                    seat.setImageResource(R.drawable.seat_notbook);
                                    bus.setSeatStatus(seatList.indexOf(seat),0);
                                    bookCount--;
                                }
                                else if (bookCount==2){
                                    Toast toast = Toast.makeText(getContext().getApplicationContext(),"You cannot book mare than 2 seat",Toast.LENGTH_SHORT);
                                    toast.setGravity(Gravity.CENTER,0,0);
                                    toast.show();
                                }
                            }

                        }
                    });
                }
            }



        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (globalClass.isLogIn()){
                    if (bookCount==0){
                        Toast toast = Toast.makeText(getContext().getApplicationContext(),"Please book the seat",Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER,0,0);
                        toast.show();
                    }
                    else if (accountLoggedIn.canBook(event,bus)){
                        bookDialog.show();
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                bookDialog.cancel();
                            }
                        });
                        confirm.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (accountLoggedIn.hasCard()){
                                    final Dialog confirmCsv = new Dialog(getContext());
                                    confirmCsv.setContentView(R.layout.dialog_confirm_csv);
                                    final EditText confirmCsvInput = (EditText)confirmCsv.findViewById(R.id.dia_confirm_csv);
                                    Button confirm = (Button) confirmCsv.findViewById(R.id.dia_csv_confirm);
                                    Button cancel = (Button)confirmCsv.findViewById(R.id.dia_csv_cancel);
                                    confirmCsv.show();
                                    confirm.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            if (confirmCsvInput.getText().toString().equals(accountLoggedIn.getSelectedCardCsv())){
                                                for (ImageView seat:seatList) {
                                                    if (seatStatus[seatList.indexOf(seat)] == 1 ){
                                                        seat.setImageResource(R.drawable.seat_booked);
                                                        bus.setSeatStatus(seatList.indexOf(seat),2);
                                                        bus.bookSeat();
                                                        seatPosition += bus.getSeatPosition(seatList.indexOf(seat)) + " ";
                                                        eventDetailBook.setText(bus.toString()+"\n"+bus.getSeatLeft()+"");
                                                        bookDialog.cancel();
                                                        confirmCsv.cancel();
                                                    }
                                                }
                                                globalClass.fromBooking();

                                                if (accountLoggedIn.isInBookList(event,bus)){
                                                    accountLoggedIn.setBookingList(event,bus,seatPosition);
                                                }
                                                else {
                                                    accountLoggedIn.addBookingList(0,event.getEventID(),bus.getBusID(),seatPosition,bookCount);
                                                }
                                                BottomNavigationView navView = getActivity().findViewById(R.id.nav_view);
                                                navView.setSelectedItemId(R.id.navigation_booking);
                                            }
                                            else {Toast.makeText(getContext().getApplicationContext(),"Incorrect Card csv",Toast.LENGTH_SHORT).show();}
                                        }
                                    });
                                    cancel.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            confirmCsv.cancel();
                                        }
                                    });

                                }
                                else{Toast.makeText(getContext().getApplicationContext(),"Please add the card",Toast.LENGTH_SHORT).show();}

                            }
                        });

                    }
                    else {
                        Toast.makeText(getContext().getApplicationContext(),"cannot book more than 2 seat in 1 bus",Toast.LENGTH_SHORT).show();
                    }

                    eventDetailBook.setText(bus.toString()+"\n"+bus.getSeatTotal()+"");
                }
                else {Toast.makeText(getContext().getApplicationContext(),"Please Login",Toast.LENGTH_SHORT).show();}

                }
        });
        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookDialog = new Dialog(getContext());
        bookDialog.setContentView(R.layout.dialog_confirm_book);
        GlobalClass globalClass = (GlobalClass)getContext().getApplicationContext();
        event = globalClass.getEvents(getArguments().getInt("eventID"));
        for (Bus b :globalClass.getBusToEvent(event)) {
            if (b.getBusID() == getArguments().getInt("busID")){
                bus = b;
            }
        }
        accountLoggedIn = globalClass.getAccountLogIn();
        if (globalClass.isLogIn()){bookCount = accountLoggedIn.getBookCount(event,bus);}
        TextView dia_busType = (TextView)bookDialog.findViewById(R.id.dia_busType);
        TextView dia_destination = (TextView)bookDialog.findViewById(R.id.dia_destination);
        TextView dia_event = (TextView)bookDialog.findViewById(R.id.dia_event);
        TextView dia_discipline = (TextView)bookDialog.findViewById(R.id.dia_discipline);
        TextView dia_category = (TextView)bookDialog.findViewById(R.id.dia_category);
        cancel = (Button) bookDialog.findViewById(R.id.cancel);
        confirm = (Button)bookDialog.findViewById(R.id.confirm);
        dia_busType.setText(bus.getBusType());
        dia_destination.setText(bus.getDestination());
        dia_event.setText(event.getSport());
        dia_discipline.setText(event.getDiscipline());
        dia_category.setText(event.getCategory());
    }
}
