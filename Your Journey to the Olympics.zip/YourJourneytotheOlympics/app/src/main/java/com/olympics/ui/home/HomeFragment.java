package com.olympics.ui.home;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Event;
import com.olympics.FileManager;
import com.olympics.MainActivity;
import com.olympics.R;
import com.olympics.RecycleViewAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    View v;
    private RecyclerView eventRecycleView;
    private List<Home> listEvent;
    private String allLine = "";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        eventRecycleView = (RecyclerView)root.findViewById(R.id.home_recycle);
        RecycleViewAdapter recycleAdapter = new RecycleViewAdapter(getContext(),listEvent);
        eventRecycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
        eventRecycleView.setAdapter(recycleAdapter);
    return root;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readFile();
        Event event1 = new Event(0);
        Event event2 = new Event(1);
        Event event3 = new Event(2);
        Event event4 = new Event(3);
        Event event5 = new Event(4);
        Event event6 = new Event(5);
        Event event7 = new Event(6);
        Event event8 = new Event(7);
        Event event9 = new Event(8);
        Event event10 = new Event(9);
        Event event11 = new Event(10);
        listEvent = new ArrayList<>();
        listEvent.add(new Home(event1.getSport(),event1.getDiscipline(),event1.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event2.getSport(),event2.getDiscipline(),event2.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event3.getSport(),event3.getDiscipline(),event3.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event4.getSport(),event4.getDiscipline(),event4.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event5.getSport(),event5.getDiscipline(),event5.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event6.getSport(),event6.getDiscipline(),event6.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event7.getSport(),event7.getDiscipline(),event7.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event8.getSport(),event8.getDiscipline(),event8.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event9.getSport(),event9.getDiscipline(),event9.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event10.getSport(),event10.getDiscipline(),event10.getCategory(),R.drawable.ic_account_box_black_24dp));
        listEvent.add(new Home(event11.getSport(),event11.getDiscipline(),event11.getCategory(),R.drawable.ic_account_box_black_24dp));

    }
    public void readFile(){

        try {
            InputStream is = getResources().openRawResource(R.raw.input);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while (reader.ready()) {
                line = reader.readLine() + "\n";
                if (line.contains("//")){continue;}
                if (line.contains("Event")){
                    line = line.replace("Event","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",9);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addEvents(lineArr);
                }
                else if (line.contains("Bus")){
                    line = line.replace("Bus","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",8);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addBuses(lineArr);
                }
                else if (line.contains("Account")){
                    line = line.replace("Account","");
                    line = line.replace(":",",");
                    String[] lineArr = line.split(",",3);
                    for (int i = 0; i < lineArr.length; i++) {
                        lineArr[i] = lineArr[i].trim();
                    }
                    new FileManager().addAccounts(lineArr);
                }
            }
        reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String getAllLine(){
        readFile();
        return allLine;
    }
}
