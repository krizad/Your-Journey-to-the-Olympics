package com.olympics.ui.home;

import android.widget.ScrollView;

public class Home {
    private String sport;
    private String discipline;
    private String category;
    private int photo;
    public Home(){}

    public Home(String sport, String discipline, String category, int photo) {
        this.sport = sport;
        this.discipline = discipline;
        this.category = category;
        this.photo = photo;
    }

    public String getSport() {
        return sport;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getCategory() {
        return category;
    }

    public int getPhoto() {
        return photo;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }
}


