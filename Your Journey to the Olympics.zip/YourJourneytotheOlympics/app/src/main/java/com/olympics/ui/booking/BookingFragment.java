package com.olympics.ui.booking;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Account;
import com.olympics.Bus;
import com.olympics.Event;
import com.olympics.GlobalClass;
import com.olympics.R;

import java.util.ArrayList;

public class BookingFragment extends Fragment {
    private RecyclerView bookingRecycleView;
    ArrayList<Integer[]> bookingLst = new ArrayList<>();
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_booking, container, false);
        GlobalClass globalClass = (GlobalClass) getContext().getApplicationContext();
        //globalClass.sortBookingListByDepartTime();
        //globalClass.sortBookingListByStatus();
        if (globalClass.isLogIn()){
            Account accountLoggedIn = globalClass.getAccountLogIn();
            bookingLst = accountLoggedIn.getBookingList();
            BookingRecycleAdapter recycleAdapter = new BookingRecycleAdapter(getContext(),bookingLst);
            bookingRecycleView = (RecyclerView)root.findViewById(R.id.booking_recycle);
            bookingRecycleView.setLayoutManager(new LinearLayoutManager(getActivity()));
            bookingRecycleView.setAdapter(recycleAdapter);
        }


        return root;
    }
}
