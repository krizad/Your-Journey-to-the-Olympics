package com.olympics;
public class Event extends FileManager{
    private String EventID;
    private String sport;
    private String discipline;
    private String category;
    private String venue;
    private String date;
    private String startTime;
    private String duration;
    private String busTravelTime;

    public Event(int index){
        super();
        this.EventID = super.getEvents().get(index)[0];
        this.sport = super.getEvents().get(index)[1];
        this.discipline = super.getEvents().get(index)[2];
        this.category = super.getEvents().get(index)[3];
        this.venue = super.getEvents().get(index)[4];
        this.date = super.getEvents().get(index)[5];
        this.startTime = super.getEvents().get(index)[6];
        this.duration = super.getEvents().get(index)[7];
        this.busTravelTime = super.getEvents().get(index)[8];
    }

    public int getEventID() {
        return Integer.parseInt(EventID);
    }

    public String getSport() {
        return sport;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getCategory() {
        return category;
    }

    public String getVenue() {
        return venue;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }

    public int getDuration() {
        int time;
        if (duration.contains(".")){
        int hour = Integer.parseInt(duration.substring(0,duration.indexOf(".")));
        int min = Integer.parseInt(duration.substring(duration.indexOf(".")+1,duration.length()));
        time = hour*60 + min;}
        else {time = Integer.parseInt(duration)*60;}

        return time;
    }
    public int getBusTravelTime() {
        int busTravelTime = Integer.parseInt(this.busTravelTime);
        return busTravelTime;
    }
    @Override
    public String toString(){
        return "Event ID : "+getEventID()+"\n"+"Sport : "+getSport()+"\n"+"Discipline : "+getDiscipline()+"\n"+"Category : "+getCategory()+"\n"+"Venue : "+getVenue()+"\n"+"Date : "+getDate()+"\n"+"Start time : "+getStartTime()+"\n"+"Duration : "+getDuration()+"\n"+"Bus travel time : "+getBusTravelTime();
    }
}
