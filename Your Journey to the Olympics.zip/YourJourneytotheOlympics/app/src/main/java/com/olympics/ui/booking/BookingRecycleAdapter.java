package com.olympics.ui.booking;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.olympics.Account;
import com.olympics.Bus;
import com.olympics.Event;
import com.olympics.GlobalClass;
import com.olympics.R;

import java.util.ArrayList;

public class BookingRecycleAdapter extends RecyclerView.Adapter<BookingRecycleAdapter.MyViewHolder> {
    Context mContext;
    ArrayList<Integer[]> mData;
    Event event;
    Bus bus;
    Account accountLoggedIn;
    public BookingRecycleAdapter(Context mContext, ArrayList<Integer[]> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @SuppressLint("ResourceAsColor")
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        v = LayoutInflater.from(mContext).inflate(R.layout.item_booking, parent, false);
        final MyViewHolder vHolder = new MyViewHolder(v);
        return vHolder;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final GlobalClass globalClass = (GlobalClass)mContext.getApplicationContext();
        event = globalClass.getEvents(mData.get(position)[1]);
        for (Bus b :globalClass.getBusToEvent(event)) {
            if (b.getBusID() == mData.get(position)[2]){
                bus = b;
            }
        }
        //bus = globalClass.getBuses(mData.get(position)[2]);
        accountLoggedIn =globalClass.getAccountLogIn();
        final int[]seatStatus = bus.getSeatStatus();
        final ArrayList<Integer> seatBookedIndex = new ArrayList<>();
        String seatBooked = accountLoggedIn.getSeatBookedPosition(bus);

        if (globalClass.IsFromBook() && position == 0){
            holder.item.setBackgroundColor(R.color.colorAccent);
        }
        if (mData.get(position)[0] == 1){holder.item.setBackgroundColor(R.color.colorPrimary);}
        holder.depart.setText("Depart Time : "+bus.getDepart());
        holder.event.setText("Event : "+event.getSport());
        holder.discipline.setText(event.getDiscipline());
        holder.category.setText(event.getCategory());
        holder.busType.setText("Bus Type : "+bus.getBusType());
        holder.seatNO.setText("Seat : "+seatBooked);
        holder.cancelBook.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                for (Bus b :globalClass.getBusToEvent(event)) {
                    if (b.getBusID() == mData.get(position)[2]){
                        bus = b;
                    }
                }
                holder.item.setBackgroundColor(R.color.colorPrimary);
                holder.cancelBook.setClickable(false);
                accountLoggedIn.cancelBook(position);
                for (int index:seatBookedIndex) {
                    for (int i = 0; i < seatStatus.length ; i++) {
                        bus.setSeatStatus(i,0);
                    }
                    bus.cancelBook();
                }
                holder.item.removeAllViews();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView depart;
        private TextView event;
        private TextView discipline;
        private TextView category;
        private TextView busType;
        private TextView seatNO;
        private ImageView cancelBook;
        private LinearLayout item;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            depart = (TextView) itemView.findViewById(R.id.booking_depart);
            event = (TextView) itemView.findViewById(R.id.booking_event);
            discipline = (TextView) itemView.findViewById(R.id.booking_discipline);
            category = (TextView) itemView.findViewById(R.id.booking_category);
            busType = (TextView) itemView.findViewById(R.id.booking_busType);
            seatNO = (TextView) itemView.findViewById(R.id.booking_seatNO);
            item = (LinearLayout)itemView.findViewById(R.id.booking_item);
            cancelBook = (ImageView) itemView.findViewById(R.id.booking_clear);
            cancelBook.setClickable(true);
        }
    }
}


