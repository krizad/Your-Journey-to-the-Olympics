package com.olympics;

import android.app.Application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class GlobalClass extends Application {
    private ArrayList<Event> events = new ArrayList<>();
    private ArrayList<Bus> buses = new ArrayList<>();
    private ArrayList<Account> accounts = new ArrayList<>();
    private ArrayList<Integer[]> bookingList = new ArrayList<>();
    private int bookCount;
    private boolean IsFromBooking;

    public ArrayList<Integer[]> getBookingList() {
        return bookingList;
    }

    public void addBookingList(int status,int eventID,int busID) {
        bookCount++;
        bookingList.add(0,new Integer[]{status, eventID, busID,bookCount});
    }

    public void sortBookingListByFirst(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o1[3].compareTo(o2[3]);
            }
        });
    }

    public void sortBookingListByStatus(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o1[0].compareTo(o2[0]);
            }
        });
    }

    public void sortBookingListByLast(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o2[3].compareTo(o1[3]);
            }
        });
    }

    public void sortBookingListByDepartTime(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return new Bus(o1[2]).getDepart().compareTo(new Bus(o2[2]).getDepart());
            }
        });
    }

    public boolean IsFromBook(){
        if (IsFromBooking){
            this.IsFromBooking = false;
            return true;}
        else {return false;}
    }

    public void fromBooking(){
        IsFromBooking = true;
    }

    public int getBookCount() {return bookCount;}

    public void cancelBook(int booklistIndex){
        bookingList.get(booklistIndex)[0] = 1;
    }

    public Event getEvents(int eventID) {
        for (Event event:events) {
            if (event.getEventID() == eventID){
                return event;
            }
        }
        return events.get(eventID);
    }

    public void addEvents(Event event) {
        this.events.add(event);
    }

    public void sortEventByTimeStart(){

        Collections.sort(events, new Comparator<Event>() {
            @Override
            public int compare(Event o1, Event o2) {
                return o1.getStartTime().compareTo(o2.getStartTime());
            }
        });
    }

    public Bus getBuses(int busID) {
        for (Bus bus:buses) {
            if (bus.getBusID() == busID){
                return bus;
            }
        }
        return buses.get(busID);
    }

    public void addBuses(Bus bus) {
        this.buses.add(bus);
    }

    public Account getAccounts(int index) {
        return accounts.get(index);
    }

    public void addAccount(Account account) {
        this.accounts.add(account);
    }

    public void setEvents(ArrayList<Event> events) {
        this.events = events;
    }

    public void setBuses(ArrayList<Bus> buses) {
        this.buses = buses;
    }

    public void setAccounts(ArrayList<Account> accounts) {
        this.accounts = accounts;
    }

    public ArrayList<Event> getEvents() {
        return events;
    }

    public ArrayList<Bus> getBuses() {
        return buses;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }
}
