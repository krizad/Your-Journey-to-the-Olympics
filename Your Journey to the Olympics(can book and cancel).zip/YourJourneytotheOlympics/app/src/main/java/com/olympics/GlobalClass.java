package com.olympics;

import android.app.Application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class GlobalClass extends Application {
    private ArrayList<Event> events = new ArrayList<>();
    private ArrayList<Bus> buses = new ArrayList<>();
    private ArrayList<Account> accounts = new ArrayList<>();
    private ArrayList<Integer[]> bookingList = new ArrayList<>();
    private int bookCount;

    public ArrayList<Integer[]> getBookingList() {
        return bookingList;
    }

    public void addBookingList(int status,int eventIndex,int busIndex) {
        bookCount++;
        bookingList.add(new Integer[]{status, eventIndex, busIndex,bookCount});
    }

    public void sortBookingListByFirst(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o1[3].compareTo(o2[3]);
            }
        });
    }
    public void sortBookingListByStatus(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o1[1].compareTo(o2[1]);
            }
        });
    }
    public void sortBookingListByLast(){
        Collections.sort(bookingList, new Comparator<Integer[]>() {
            @Override
            public int compare(Integer[] o1, Integer[] o2) {
                return o2[3].compareTo(o1[3]);
            }
        });
    }

    public int getBookCount() {return bookCount;}

    public void cancelBook(int booklistIndex){
        bookingList.get(booklistIndex)[0] = 1;
    }

    public Event getEvents(int index) {
        return events.get(index);
    }

    public void addEvents(Event event) {
        this.events.add(event);
    }

    public Bus getBuses(int index) {
        return buses.get(index);
    }

    public void addBuses(Bus bus) {
        this.buses.add(bus);
    }

    public Account getAccounts(int index) {
        return accounts.get(index);
    }

    public void addAccount(Account account) {
        this.accounts.add(account);
    }

    public void setEvents(ArrayList<Event> events) {
        this.events = events;
    }

    public void setBuses(ArrayList<Bus> buses) {
        this.buses = buses;
    }

    public void setAccounts(ArrayList<Account> accounts) {
        this.accounts = accounts;
    }

    public ArrayList<Event> getEvents() {
        return events;
    }

    public ArrayList<Bus> getBuses() {
        return buses;
    }

    public ArrayList<Account> getAccounts() {
        return accounts;
    }
}
